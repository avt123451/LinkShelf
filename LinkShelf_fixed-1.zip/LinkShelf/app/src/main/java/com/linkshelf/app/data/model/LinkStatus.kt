package com.linkshelf.app.data.model

import androidx.compose.ui.graphics.Color

/**
 * Status badge shown on each card. Colors chosen for contrast on a dark theme.
 */
enum class LinkStatus(val label: String, val color: Color) {
    NOT_VIEWED("Не подивився", Color(0xFF5C6BC0)),
    VIEWED("Подивився", Color(0xFF43A047)),
    WANT_TO_BUY("Хочу купити", Color(0xFFFB8C00)),
    BOUGHT("Куплено", Color(0xFF00897B)),
    FAVORITE("Вибране", Color(0xFFE53935)),
    ARCHIVE("Архів", Color(0xFF757575));

    companion object {
        fun fromName(name: String): LinkStatus =
            entries.firstOrNull { it.name == name } ?: NOT_VIEWED
    }
}
