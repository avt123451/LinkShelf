package com.linkshelf.app.data.export

import android.content.Context
import android.net.Uri
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.linkshelf.app.data.local.entity.LinkEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Exports/imports the full card collection.
 * JSON preserves every field losslessly; CSV is provided for spreadsheet users
 * (tags/notes are quoted to survive commas).
 */
class ExportImportManager(private val context: Context) {

    private val gson = Gson()

    suspend fun exportJson(uri: Uri, links: List<LinkEntity>) = withContext(Dispatchers.IO) {
        context.contentResolver.openOutputStream(uri)?.use { out ->
            out.write(gson.toJson(links).toByteArray())
        }
    }

    suspend fun importJson(uri: Uri): List<LinkEntity> = withContext(Dispatchers.IO) {
        context.contentResolver.openInputStream(uri)?.use { input ->
            val json = input.bufferedReader().readText()
            val type = object : TypeToken<List<LinkEntity>>() {}.type
            gson.fromJson<List<LinkEntity>>(json, type)
        } ?: emptyList()
    }

    suspend fun exportCsv(uri: Uri, links: List<LinkEntity>) = withContext(Dispatchers.IO) {
        context.contentResolver.openOutputStream(uri)?.use { out ->
            val header = "url,title,domain,folder,status,tags,notes,dateAdded\n"
            out.write(header.toByteArray())
            links.forEach { l ->
                val row = listOf(l.url, l.title, l.domain, l.folder, l.status, l.tags, l.notes, l.dateAdded.toString())
                    .joinToString(",") { "\"${it.replace("\"", "\"\"")}\"" }
                out.write((row + "\n").toByteArray())
            }
        }
    }
}
