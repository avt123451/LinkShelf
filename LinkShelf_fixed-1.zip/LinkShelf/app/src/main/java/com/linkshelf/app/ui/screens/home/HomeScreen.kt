package com.linkshelf.app.ui.screens.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.net.toUri
import com.linkshelf.app.data.model.LinkFolder
import com.linkshelf.app.data.model.LinkStatus
import com.linkshelf.app.data.repository.SortOption
import com.linkshelf.app.ui.components.LinkCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onAddClick: () -> Unit,
    onOpenFoldersView: () -> Unit,
    onOpenDetail: (Long) -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    var showSortMenu by remember { mutableStateOf(false) }
    var statusPickerFor by remember { mutableStateOf<Long?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("LinkShelf") },
                actions = {
                    IconButton(onClick = onOpenFoldersView) {
                        Icon(Icons.Filled.GridView, contentDescription = "Папки-вкладки")
                    }
                    Box {
                        IconButton(onClick = { showSortMenu = true }) {
                            Icon(Icons.Filled.Sort, contentDescription = "Сортування")
                        }
                        DropdownMenu(expanded = showSortMenu, onDismissRequest = { showSortMenu = false }) {
                            DropdownMenuItem(text = { Text("За датою") }, onClick = { viewModel.setSort(SortOption.DATE); showSortMenu = false })
                            DropdownMenuItem(text = { Text("За назвою") }, onClick = { viewModel.setSort(SortOption.TITLE); showSortMenu = false })
                            DropdownMenuItem(text = { Text("За сайтом") }, onClick = { viewModel.setSort(SortOption.DOMAIN); showSortMenu = false })
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = onAddClick, icon = { Icon(Icons.Filled.Add, null) }, text = { Text("Додати") })
        },
        bottomBar = {
            if (state.selectionMode) {
                BottomAppBar {
                    Text("  Обрано: ${state.selectedIds.size}", modifier = Modifier.weight(1f))
                    var showMoveMenu by remember { mutableStateOf(false) }
                    Box {
                        TextButton(onClick = { showMoveMenu = true }) { Text("Перемістити") }
                        DropdownMenu(expanded = showMoveMenu, onDismissRequest = { showMoveMenu = false }) {
                            LinkFolder.entries.forEach { f ->
                                DropdownMenuItem(text = { Text(f.displayName) }, onClick = {
                                    viewModel.bulkMoveSelected(f.name); showMoveMenu = false
                                })
                            }
                        }
                    }
                    TextButton(onClick = { viewModel.bulkDeleteSelected() }) { Text("Видалити") }
                    TextButton(onClick = { viewModel.clearSelection() }) { Text("Скасувати") }
                }
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding)) {
            OutlinedTextField(
                value = state.query,
                onValueChange = viewModel::setQuery,
                placeholder = { Text("Пошук за назвою, доменом, тегом...") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            )

            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScrollPadding()
            ) {
                FilterChip(
                    selected = state.folder == null,
                    onClick = { viewModel.setFolder(null) },
                    label = { Text("Усі папки") },
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                LinkFolder.entries.forEach { f ->
                    FilterChip(
                        selected = state.folder == f.name,
                        onClick = { viewModel.setFolder(if (state.folder == f.name) null else f.name) },
                        label = { Text(f.displayName) },
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                }
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp)
            ) {
                FilterChip(
                    selected = state.status == null,
                    onClick = { viewModel.setStatus(null) },
                    label = { Text("Усі статуси") },
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                FilterChip(
                    selected = state.status == LinkStatus.NOT_VIEWED.name,
                    onClick = { viewModel.setStatus(if (state.status == LinkStatus.NOT_VIEWED.name) null else LinkStatus.NOT_VIEWED.name) },
                    label = { Text("Не переглянуті") },
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                FilterChip(
                    selected = state.status == LinkStatus.VIEWED.name,
                    onClick = { viewModel.setStatus(if (state.status == LinkStatus.VIEWED.name) null else LinkStatus.VIEWED.name) },
                    label = { Text("Переглянуті") },
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(state.links, key = { it.id }) { link ->
                    LinkCard(
                        link = link,
                        selected = link.id in state.selectedIds,
                        selectionMode = state.selectionMode,
                        onOpen = { context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, link.url.toUri())) },
                        onChangeStatus = { statusPickerFor = link.id },
                        onTogglePin = { viewModel.togglePin(link.id, !link.isPinned) },
                        onClick = {
                            if (state.selectionMode) viewModel.toggleSelected(link.id) else onOpenDetail(link.id)
                        },
                        onLongClick = { viewModel.toggleSelected(link.id) }
                    )
                }
            }
        }
    }

    statusPickerFor?.let { id ->
        ModalBottomSheet(onDismissRequest = { statusPickerFor = null }) {
            Column(Modifier.padding(16.dp)) {
                Text("Обрати статус", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                LinkStatus.entries.forEach { s ->
                    ListItem(
                        headlineContent = { Text(s.label) },
                        modifier = Modifier.clickable {
                            viewModel.setStatusFor(id, s)
                            statusPickerFor = null
                        }
                    )
                }
            }
        }
    }
}

// Small local helper kept in-file to avoid an extra boilerplate file.
private fun Modifier.horizontalScrollPadding(): Modifier = this.padding(horizontal = 4.dp)
