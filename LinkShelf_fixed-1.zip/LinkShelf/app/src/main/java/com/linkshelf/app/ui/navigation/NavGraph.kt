package com.linkshelf.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.linkshelf.app.data.repository.LinkRepository
import com.linkshelf.app.ui.SimpleViewModelFactory
import com.linkshelf.app.ui.screens.addlink.AddLinkScreen
import com.linkshelf.app.ui.screens.addlink.AddLinkViewModel
import com.linkshelf.app.ui.screens.detail.LinkDetailScreen
import com.linkshelf.app.ui.screens.folders.FoldersScreen
import com.linkshelf.app.ui.screens.home.HomeScreen
import com.linkshelf.app.ui.screens.home.HomeViewModel

object Routes {
    const val HOME = "home"
    const val FOLDERS = "folders"
    const val ADD = "add?url={url}"
    const val DETAIL = "detail/{id}"
    fun add(url: String? = null) = "add?url=${url ?: ""}"
    fun detail(id: Long) = "detail/$id"
}

@Composable
fun LinkShelfNavGraph(repository: LinkRepository, initialSharedUrl: String? = null) {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            val vm: HomeViewModel = viewModel(factory = SimpleViewModelFactory { HomeViewModel(repository) })
            HomeScreen(
                viewModel = vm,
                onAddClick = { navController.navigate(Routes.add()) },
                onOpenFoldersView = { navController.navigate(Routes.FOLDERS) },
                onOpenDetail = { id -> navController.navigate(Routes.detail(id)) }
            )
        }
        composable(Routes.FOLDERS) {
            FoldersScreen(
                repository = repository,
                onBack = { navController.popBackStack() },
                onFolderClick = { folder ->
                    navController.popBackStack()
                    // HomeScreen already exposes a folder filter chip; a deep link into
                    // a pre-filtered Home is a natural follow-up extension point here.
                }
            )
        }
        composable(
            route = Routes.ADD,
            arguments = listOf(navArgument("url") { type = NavType.StringType; defaultValue = "" })
        ) { backStackEntry ->
            val url = backStackEntry.arguments?.getString("url").orEmpty().ifBlank { initialSharedUrl }
            val vm: AddLinkViewModel = viewModel(factory = SimpleViewModelFactory { AddLinkViewModel(repository) })
            AddLinkScreen(
                viewModel = vm,
                prefillUrl = url,
                onBack = { navController.popBackStack() },
                onSaved = { navController.popBackStack() }
            )
        }
        composable(
            route = Routes.DETAIL,
            arguments = listOf(navArgument("id") { type = NavType.LongType })
        ) { backStackEntry ->
            val id = backStackEntry.arguments?.getLong("id") ?: return@composable
            LinkDetailScreen(
                linkId = id,
                repository = repository,
                onBack = { navController.popBackStack() },
                onDeleted = { navController.popBackStack() }
            )
        }
    }
}
