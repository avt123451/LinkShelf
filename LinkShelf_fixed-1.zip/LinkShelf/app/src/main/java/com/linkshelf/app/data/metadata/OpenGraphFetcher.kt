package com.linkshelf.app.data.metadata

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.net.URI
import java.util.concurrent.TimeUnit

data class PageMetadata(
    val title: String,
    val description: String?,
    val imageUrl: String?,
    val faviconUrl: String?,
    val domain: String,
    val fetchFailed: Boolean = false
)

/**
 * Downloads a page and extracts Open Graph / fallback metadata.
 * Never throws — on any network or parsing error it returns a best-effort
 * PageMetadata built from the URL alone, with fetchFailed = true, so the UI
 * can show a placeholder image instead of crashing (per "sайт без preview" req).
 */
class OpenGraphFetcher {

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    suspend fun fetch(rawUrl: String): PageMetadata = withContext(Dispatchers.IO) {
        val url = normalize(rawUrl)
        val domain = runCatching { URI(url).host.removePrefix("www.") }.getOrDefault(url)

        try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Android; LinkShelf)")
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext fallback(url, domain)
                val html = response.body?.string() ?: return@withContext fallback(url, domain)
                val doc = Jsoup.parse(html, url)

                val ogTitle = doc.select("meta[property=og:title]").attr("content").ifBlank { doc.title() }
                val ogDesc = doc.select("meta[property=og:description]").attr("content")
                    .ifBlank { doc.select("meta[name=description]").attr("content") }
                val ogImage = doc.select("meta[property=og:image]").attr("abs:content")

                val favicon = doc.select("link[rel~=(?i)icon]").attr("abs:href")
                    .ifBlank { "https://www.google.com/s2/favicons?domain=$domain&sz=64" }

                PageMetadata(
                    title = ogTitle.ifBlank { domain },
                    description = ogDesc.ifBlank { null },
                    imageUrl = ogImage.ifBlank { null },
                    faviconUrl = favicon,
                    domain = domain,
                    fetchFailed = false
                )
            }
        } catch (e: Exception) {
            fallback(url, domain)
        }
    }

    private fun fallback(url: String, domain: String) = PageMetadata(
        title = domain,
        description = null,
        imageUrl = null, // UI shows a placeholder gradient card when null
        faviconUrl = "https://www.google.com/s2/favicons?domain=$domain&sz=64",
        domain = domain,
        fetchFailed = true
    )

    private fun normalize(raw: String): String {
        val trimmed = raw.trim()
        return if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) trimmed
        else "https://$trimmed"
    }
}
