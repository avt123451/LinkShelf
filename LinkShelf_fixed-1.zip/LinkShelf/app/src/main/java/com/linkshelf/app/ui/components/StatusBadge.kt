package com.linkshelf.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linkshelf.app.data.model.LinkStatus

@Composable
fun StatusBadge(status: LinkStatus, modifier: Modifier = Modifier) {
    Text(
        text = status.label,
        color = Color.White,
        fontSize = 11.sp,
        modifier = modifier
            .background(status.color, RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}
