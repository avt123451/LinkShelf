package com.linkshelf.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A single saved link ("card"). All metadata fields are nullable because a site
 * may not expose Open Graph data (see OpenGraphFetcher error handling).
 */
@Entity(tableName = "links")
data class LinkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,

    val url: String,
    val title: String,
    val description: String? = null,
    val thumbnailUrl: String? = null,   // og:image
    val faviconUrl: String? = null,
    val domain: String,

    val folder: String,                 // LinkFolder.name, or a custom folder key
    val status: String,                 // LinkStatus.name

    val tags: String = "",              // comma-separated, simple + fast for local search
    val notes: String = "",

    val isPinned: Boolean = false,
    val dateAdded: Long = System.currentTimeMillis(),
    val dateModified: Long = System.currentTimeMillis(),

    val metadataFetchFailed: Boolean = false
)
