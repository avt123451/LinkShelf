package com.linkshelf.app.share

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import com.linkshelf.app.MainActivity

/**
 * Invisible activity registered for ACTION_SEND / text/plain, which is how
 * Chrome's "Share" menu delivers a URL. Extracts the URL and forwards the
 * user straight into MainActivity -> Add Link screen, pre-filled.
 */
class ShareReceiverActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val sharedText = if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            intent.getStringExtra(Intent.EXTRA_TEXT)
        } else null

        val url = extractUrl(sharedText)

        val forward = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(MainActivity.EXTRA_SHARED_URL, url)
        }
        startActivity(forward)
        finish()
    }

    /** Chrome often shares "Page Title\nhttps://example.com" — pull just the URL out. */
    private fun extractUrl(text: String?): String? {
        if (text.isNullOrBlank()) return null
        val regex = Regex("""https?://\S+""")
        return regex.find(text)?.value ?: text.trim()
    }
}
