package com.linkshelf.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.linkshelf.app.data.local.dao.LinkDao
import com.linkshelf.app.data.local.entity.LinkEntity

@Database(entities = [LinkEntity::class], version = 1, exportSchema = true)
abstract class LinkShelfDatabase : RoomDatabase() {

    abstract fun linkDao(): LinkDao

    companion object {
        @Volatile private var INSTANCE: LinkShelfDatabase? = null

        fun getInstance(context: Context): LinkShelfDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    LinkShelfDatabase::class.java,
                    "linkshelf.db"
                ).build().also { INSTANCE = it }
            }
    }
}
