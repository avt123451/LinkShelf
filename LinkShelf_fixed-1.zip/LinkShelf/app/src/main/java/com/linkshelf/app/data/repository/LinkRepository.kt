package com.linkshelf.app.data.repository

import com.linkshelf.app.data.local.dao.FolderCount
import com.linkshelf.app.data.local.dao.LinkDao
import com.linkshelf.app.data.local.entity.LinkEntity
import com.linkshelf.app.data.metadata.OpenGraphFetcher
import com.linkshelf.app.data.model.LinkStatus
import kotlinx.coroutines.flow.Flow

enum class SortOption(val key: String) { DATE("date"), TITLE("title"), DOMAIN("domain") }

class LinkRepository(
    private val dao: LinkDao,
    private val fetcher: OpenGraphFetcher = OpenGraphFetcher()
) {
    /** Fetches OG metadata for a pasted/shared URL. Called before showing the "confirm & pick folder" screen. */
    suspend fun fetchPreview(url: String) = fetcher.fetch(url)

    suspend fun saveLink(
        url: String,
        title: String,
        description: String?,
        thumbnailUrl: String?,
        faviconUrl: String?,
        domain: String,
        folder: String,
        status: LinkStatus = LinkStatus.NOT_VIEWED,
        tags: String = "",
        notes: String = "",
        fetchFailed: Boolean = false
    ): Long = dao.insert(
        LinkEntity(
            url = url,
            title = title,
            description = description,
            thumbnailUrl = thumbnailUrl,
            faviconUrl = faviconUrl,
            domain = domain,
            folder = folder,
            status = status.name,
            tags = tags,
            notes = notes,
            metadataFetchFailed = fetchFailed
        )
    )

    suspend fun updateLink(link: LinkEntity) = dao.update(link.copy(dateModified = System.currentTimeMillis()))

    suspend fun deleteLinks(ids: List<Long>) = dao.deleteByIds(ids)

    suspend fun moveToFolder(ids: List<Long>, folder: String) = dao.moveToFolder(ids, folder)

    suspend fun setStatus(id: Long, status: LinkStatus) = dao.setStatus(id, status.name)

    suspend fun togglePinned(id: Long, pinned: Boolean) = dao.setPinned(id, pinned)

    suspend fun getById(id: Long) = dao.getById(id)

    fun folderCounts(): Flow<List<FolderCount>> = dao.getFolderCounts()

    fun search(
        folder: String?,
        status: String?,
        query: String?,
        sortBy: SortOption
    ): Flow<List<LinkEntity>> = dao.search(folder, status, query?.trim(), sortBy.key)

    fun getAll(): Flow<List<LinkEntity>> = dao.getAll()

    suspend fun insertAll(links: List<LinkEntity>) = dao.insertAll(links)
}
