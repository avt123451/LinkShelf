package com.linkshelf.app.ui.screens.folders

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.linkshelf.app.data.model.LinkFolder
import com.linkshelf.app.data.repository.LinkRepository

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FoldersScreen(
    repository: LinkRepository,
    onBack: () -> Unit,
    onFolderClick: (LinkFolder) -> Unit
) {
    val counts by repository.folderCounts().collectAsState(initial = emptyList())
    val countMap = counts.associate { it.folder to it.count }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Папки") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Назад") }
                }
            )
        }
    ) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.padding(padding)
        ) {
            items(LinkFolder.entries.toList()) { folder ->
                com.linkshelf.app.ui.components.FolderTile(
                    folder = folder,
                    count = countMap[folder.name] ?: 0,
                    onClick = { onFolderClick(folder) }
                )
            }
        }
    }
}
