package com.linkshelf.app.data.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Built-in folders shown as tiles on the "Folders" (browser-tabs-like) screen.
 * Stored as a string key on LinkEntity.folder so custom folders can be added later
 * without a schema migration (see LinkRepository.customFolders).
 */
enum class LinkFolder(val displayName: String, val icon: ImageVector) {
    WATCHED("Подивився", Icons.Filled.Visibility),
    NOT_WATCHED("Не подивився", Icons.Filled.VisibilityOff),
    WANT_TO_BUY("Хочу купити", Icons.Filled.ShoppingCart),
    WATCH_LATER("Подивлюсь потім", Icons.Filled.WatchLater),
    ANIME("Аніме", Icons.Filled.Movie),
    MOVIES("Фільми", Icons.Filled.LocalMovies),
    OTHER("Інше", Icons.Filled.Folder);

    companion object {
        fun fromKey(key: String): LinkFolder =
            entries.firstOrNull { it.name == key } ?: OTHER
    }
}
