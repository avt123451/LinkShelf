package com.linkshelf.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linkshelf.app.data.model.LinkFolder

/**
 * Bonus feature: each folder rendered as a big tile with an item counter,
 * resembling Chrome's "tab group" grid view.
 */
@Composable
fun FolderTile(
    folder: LinkFolder,
    count: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.linearGradient(
                    listOf(
                        MaterialTheme.colorScheme.surfaceVariant,
                        MaterialTheme.colorScheme.surface
                    )
                )
            )
            .clickable(onClick = onClick)
            .padding(16.dp)
            .height(110.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Icon(
            folder.icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(28.dp)
        )
        Column {
            Text(folder.displayName, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(
                "$count " + pluralItems(count),
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private fun pluralItems(count: Int): String {
    val mod10 = count % 10
    val mod100 = count % 100
    return when {
        mod10 == 1 && mod100 != 11 -> "посилання"
        mod10 in 2..4 && (mod100 !in 12..14) -> "посилання"
        else -> "посилань"
    }
}
