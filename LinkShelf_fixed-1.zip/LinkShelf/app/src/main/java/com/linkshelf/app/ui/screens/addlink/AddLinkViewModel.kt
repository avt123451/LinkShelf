package com.linkshelf.app.ui.screens.addlink

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.linkshelf.app.data.metadata.PageMetadata
import com.linkshelf.app.data.model.LinkFolder
import com.linkshelf.app.data.model.LinkStatus
import com.linkshelf.app.data.repository.LinkRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AddLinkUiState(
    val url: String = "",
    val loading: Boolean = false,
    val metadata: PageMetadata? = null,
    val editedTitle: String = "",
    val editedImageUrl: String? = null,
    val folder: LinkFolder = LinkFolder.OTHER,
    val tags: String = "",
    val notes: String = "",
    val saved: Boolean = false,
    val error: String? = null
)

class AddLinkViewModel(private val repository: LinkRepository) : ViewModel() {

    private val _state = MutableStateFlow(AddLinkUiState())
    val state: StateFlow<AddLinkUiState> = _state.asStateFlow()

    fun setUrl(url: String) { _state.value = _state.value.copy(url = url) }

    /** Called after paste / share — fetches title, og:image, description, favicon. */
    fun fetchPreview() = viewModelScope.launch {
        val url = _state.value.url.trim()
        if (url.isBlank()) {
            _state.value = _state.value.copy(error = "Вставте посилання")
            return@launch
        }
        _state.value = _state.value.copy(loading = true, error = null)
        val meta = repository.fetchPreview(url)
        _state.value = _state.value.copy(
            loading = false,
            metadata = meta,
            editedTitle = meta.title,
            editedImageUrl = meta.imageUrl,
            error = if (meta.fetchFailed) "Не вдалося отримати прев'ю — можна додати вручну" else null
        )
    }

    fun setEditedTitle(t: String) { _state.value = _state.value.copy(editedTitle = t) }
    fun setEditedImageUrl(u: String) { _state.value = _state.value.copy(editedImageUrl = u.ifBlank { null }) }
    fun setFolder(f: LinkFolder) { _state.value = _state.value.copy(folder = f) }
    fun setTags(t: String) { _state.value = _state.value.copy(tags = t) }
    fun setNotes(n: String) { _state.value = _state.value.copy(notes = n) }

    fun save() = viewModelScope.launch {
        val s = _state.value
        val meta = s.metadata
        repository.saveLink(
            url = s.url.trim(),
            title = s.editedTitle.ifBlank { meta?.title ?: s.url },
            description = meta?.description,
            thumbnailUrl = s.editedImageUrl,
            faviconUrl = meta?.faviconUrl,
            domain = meta?.domain ?: s.url,
            folder = s.folder.name,
            status = LinkStatus.NOT_VIEWED,
            tags = s.tags,
            notes = s.notes,
            fetchFailed = meta?.fetchFailed ?: true
        )
        _state.value = _state.value.copy(saved = true)
    }
}
