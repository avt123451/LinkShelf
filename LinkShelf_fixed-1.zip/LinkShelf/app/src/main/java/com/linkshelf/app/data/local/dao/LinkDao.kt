package com.linkshelf.app.data.local.dao

import androidx.room.*
import com.linkshelf.app.data.local.entity.LinkEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface LinkDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(link: LinkEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(links: List<LinkEntity>)

    @Update
    suspend fun update(link: LinkEntity)

    @Delete
    suspend fun delete(link: LinkEntity)

    @Query("DELETE FROM links WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<Long>)

    @Query("SELECT * FROM links WHERE id = :id")
    suspend fun getById(id: Long): LinkEntity?

    @Query("SELECT * FROM links")
    fun getAll(): Flow<List<LinkEntity>>

    @Query("UPDATE links SET folder = :folder, dateModified = :now WHERE id IN (:ids)")
    suspend fun moveToFolder(ids: List<Long>, folder: String, now: Long = System.currentTimeMillis())

    @Query("UPDATE links SET status = :status, dateModified = :now WHERE id = :id")
    suspend fun setStatus(id: Long, status: String, now: Long = System.currentTimeMillis())

    @Query("UPDATE links SET isPinned = :pinned, dateModified = :now WHERE id = :id")
    suspend fun setPinned(id: Long, pinned: Boolean, now: Long = System.currentTimeMillis())

    @Query("SELECT folder, COUNT(*) as count FROM links GROUP BY folder")
    fun getFolderCounts(): Flow<List<FolderCount>>

    /**
     * Central query behind the Home screen: filters by folder, status,
     * and a text query matching title / domain / tags — all optional.
     */
    @Query(
        """
        SELECT * FROM links
        WHERE (:folder IS NULL OR folder = :folder)
        AND (:status IS NULL OR status = :status)
        AND (
            :query IS NULL OR :query = '' OR
            title LIKE '%' || :query || '%' OR
            domain LIKE '%' || :query || '%' OR
            tags LIKE '%' || :query || '%'
        )
        ORDER BY
            isPinned DESC,
            CASE WHEN :sortBy = 'date' THEN dateAdded END DESC,
            CASE WHEN :sortBy = 'title' THEN title END ASC,
            CASE WHEN :sortBy = 'domain' THEN domain END ASC
        """
    )
    fun search(
        folder: String?,
        status: String?,
        query: String?,
        sortBy: String
    ): Flow<List<LinkEntity>>
}

data class FolderCount(val folder: String, val count: Int)
