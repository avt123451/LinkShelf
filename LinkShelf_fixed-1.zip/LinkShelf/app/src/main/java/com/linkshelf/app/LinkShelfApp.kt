package com.linkshelf.app

import android.app.Application
import com.linkshelf.app.data.export.ExportImportManager
import com.linkshelf.app.data.local.LinkShelfDatabase
import com.linkshelf.app.data.metadata.OpenGraphFetcher
import com.linkshelf.app.data.repository.LinkRepository

/**
 * Simple manual dependency container (no Hilt) so the project stays easy to read
 * and modify. Swap for Hilt/Koin later if the codebase grows.
 */
class LinkShelfApp : Application() {

    lateinit var repository: LinkRepository
        private set
    lateinit var exportImportManager: ExportImportManager
        private set

    override fun onCreate() {
        super.onCreate()
        val db = LinkShelfDatabase.getInstance(this)
        repository = LinkRepository(db.linkDao(), OpenGraphFetcher())
        exportImportManager = ExportImportManager(this)
    }
}
