package com.linkshelf.app.ui.screens.addlink

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.linkshelf.app.data.model.LinkFolder

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddLinkScreen(
    viewModel: AddLinkViewModel,
    prefillUrl: String? = null,
    onBack: () -> Unit,
    onSaved: () -> Unit
) {
    val state by viewModel.state.collectAsState()
    val clipboard = LocalClipboardManager.current

    LaunchedEffect(prefillUrl) {
        if (!prefillUrl.isNullOrBlank()) {
            viewModel.setUrl(prefillUrl)
            viewModel.fetchPreview()
        }
    }
    LaunchedEffect(state.saved) { if (state.saved) onSaved() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Нове посилання") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Назад") } }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .padding(16.dp)
                .verticalScrollFix()
        ) {
            OutlinedTextField(
                value = state.url,
                onValueChange = viewModel::setUrl,
                label = { Text("URL") },
                trailingIcon = {
                    IconButton(onClick = {
                        clipboard.getText()?.text?.let { viewModel.setUrl(it) }
                    }) { Icon(Icons.Filled.ContentPaste, contentDescription = "Вставити з буфера") }
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = { viewModel.fetchPreview() }, enabled = !state.loading) {
                Text(if (state.loading) "Завантаження..." else "Отримати прев'ю")
            }

            state.error?.let {
                Spacer(Modifier.height(4.dp))
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }

            if (state.metadata != null) {
                Spacer(Modifier.height(16.dp))
                if (state.editedImageUrl != null) {
                    AsyncImage(
                        model = state.editedImageUrl,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                    )
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = state.editedTitle,
                    onValueChange = viewModel::setEditedTitle,
                    label = { Text("Назва") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = state.editedImageUrl ?: "",
                    onValueChange = viewModel::setEditedImageUrl,
                    label = { Text("URL зображення (можна змінити вручну)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(16.dp))
                Text("Папка", style = MaterialTheme.typography.titleSmall)
                LazyRow {
                    items(LinkFolder.entries) { f ->
                        FilterChip(
                            selected = state.folder == f,
                            onClick = { viewModel.setFolder(f) },
                            label = { Text(f.displayName) },
                            modifier = Modifier.padding(end = 6.dp, top = 6.dp)
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = state.tags,
                    onValueChange = viewModel::setTags,
                    label = { Text("Теги (через кому)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = state.notes,
                    onValueChange = viewModel::setNotes,
                    label = { Text("Нотатки") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(20.dp))
                Button(onClick = { viewModel.save() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Зберегти картку")
                }
            }
        }
    }
}

@Composable
private fun Modifier.verticalScrollFix(): Modifier = this.verticalScroll(rememberScrollState())
