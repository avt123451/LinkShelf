package com.linkshelf.app.ui.theme

import androidx.compose.ui.graphics.Color

val BgDark = Color(0xFF121214)
val SurfaceDark = Color(0xFF1C1C1F)
val SurfaceElevated = Color(0xFF26262A)
val AccentPrimary = Color(0xFF7C8CFF)
val AccentSecondary = Color(0xFF00D1B2)
val TextPrimary = Color(0xFFF2F2F5)
val TextSecondary = Color(0xFFA0A0AA)
val Divider = Color(0xFF2E2E33)
