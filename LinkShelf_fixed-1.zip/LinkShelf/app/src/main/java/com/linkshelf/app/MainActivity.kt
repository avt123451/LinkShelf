package com.linkshelf.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.linkshelf.app.ui.navigation.LinkShelfNavGraph
import com.linkshelf.app.ui.theme.LinkShelfTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // If launched via ShareReceiverActivity forwarding a shared URL.
        val sharedUrl = intent.getStringExtra(EXTRA_SHARED_URL)

        val app = application as LinkShelfApp

        setContent {
            LinkShelfTheme(darkTheme = true) {
                LinkShelfNavGraph(repository = app.repository, initialSharedUrl = sharedUrl)
            }
        }
    }

    companion object {
        const val EXTRA_SHARED_URL = "extra_shared_url"
    }
}
