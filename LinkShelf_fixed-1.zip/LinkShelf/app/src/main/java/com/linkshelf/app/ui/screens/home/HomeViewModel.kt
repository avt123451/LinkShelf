package com.linkshelf.app.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.linkshelf.app.data.local.entity.LinkEntity
import com.linkshelf.app.data.model.LinkStatus
import com.linkshelf.app.data.repository.LinkRepository
import com.linkshelf.app.data.repository.SortOption
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class HomeUiState(
    val links: List<LinkEntity> = emptyList(),
    val query: String = "",
    val folder: String? = null,      // null = all folders
    val status: String? = null,      // null = all statuses
    val sortBy: SortOption = SortOption.DATE,
    val selectedIds: Set<Long> = emptySet(),
    val selectionMode: Boolean = false
)

class HomeViewModel(private val repository: LinkRepository) : ViewModel() {

    private val query = MutableStateFlow("")
    private val folder = MutableStateFlow<String?>(null)
    private val status = MutableStateFlow<String?>(null)
    private val sortBy = MutableStateFlow(SortOption.DATE)
    private val selectedIds = MutableStateFlow<Set<Long>>(emptySet())

    private val filters = combine(query, folder, status, sortBy) { q, f, s, sort -> Filters(q, f, s, sort) }

    val uiState: StateFlow<HomeUiState> = filters
        .flatMapLatest { f -> repository.search(f.folder, f.status, f.query, f.sortBy) }
        .combine(selectedIds) { links, selected -> links to selected }
        .combine(filters) { (links, selected), f ->
            HomeUiState(
                links = links,
                query = f.query,
                folder = f.folder,
                status = f.status,
                sortBy = f.sortBy,
                selectedIds = selected,
                selectionMode = selected.isNotEmpty()
            )
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeUiState())

    private data class Filters(val query: String, val folder: String?, val status: String?, val sortBy: SortOption)

    fun setQuery(q: String) { query.value = q }
    fun setFolder(f: String?) { folder.value = f }
    fun setStatus(s: String?) { status.value = s }
    fun setSort(s: SortOption) { sortBy.value = s }

    fun toggleSelected(id: Long) {
        selectedIds.value = selectedIds.value.let { if (id in it) it - id else it + id }
    }
    fun clearSelection() { selectedIds.value = emptySet() }

    fun setStatusFor(id: Long, newStatus: LinkStatus) = viewModelScope.launch {
        repository.setStatus(id, newStatus)
    }

    fun togglePin(id: Long, pinned: Boolean) = viewModelScope.launch {
        repository.togglePinned(id, pinned)
    }

    fun bulkMoveSelected(folderKey: String) = viewModelScope.launch {
        repository.moveToFolder(selectedIds.value.toList(), folderKey)
        clearSelection()
    }

    fun bulkDeleteSelected() = viewModelScope.launch {
        repository.deleteLinks(selectedIds.value.toList())
        clearSelection()
    }
}
