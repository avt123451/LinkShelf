package com.linkshelf.app.ui.screens.detail

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.linkshelf.app.data.local.entity.LinkEntity
import com.linkshelf.app.data.model.LinkFolder
import com.linkshelf.app.data.model.LinkStatus
import com.linkshelf.app.data.repository.LinkRepository
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LinkDetailScreen(
    linkId: Long,
    repository: LinkRepository,
    onBack: () -> Unit,
    onDeleted: () -> Unit
) {
    var link by remember { mutableStateOf<LinkEntity?>(null) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(linkId) { link = repository.getById(linkId) }

    val current = link ?: run {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }

    var title by remember(current.id) { mutableStateOf(current.title) }
    var imageUrl by remember(current.id) { mutableStateOf(current.thumbnailUrl ?: "") }
    var tags by remember(current.id) { mutableStateOf(current.tags) }
    var notes by remember(current.id) { mutableStateOf(current.notes) }
    var folder by remember(current.id) { mutableStateOf(LinkFolder.fromKey(current.folder)) }
    var status by remember(current.id) { mutableStateOf(LinkStatus.fromName(current.status)) }
    var pinned by remember(current.id) { mutableStateOf(current.isPinned) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Картка") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Назад") } },
                actions = {
                    IconButton(onClick = { pinned = !pinned }) {
                        Icon(Icons.Filled.PushPin, contentDescription = "Закріпити", tint = if (pinned) MaterialTheme.colorScheme.primary else LocalContentColor.current)
                    }
                    IconButton(onClick = {
                        scope.launch { repository.deleteLinks(listOf(current.id)); onDeleted() }
                    }) { Icon(Icons.Filled.Delete, contentDescription = "Видалити") }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            if (imageUrl.isNotBlank()) {
                AsyncImage(
                    model = imageUrl, contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().height(180.dp)
                )
                Spacer(Modifier.height(12.dp))
            }

            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Назва") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = imageUrl, onValueChange = { imageUrl = it }, label = { Text("URL зображення") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Text(current.domain, style = MaterialTheme.typography.bodySmall)

            Spacer(Modifier.height(16.dp))
            Text("Папка", style = MaterialTheme.typography.titleSmall)
            LazyRow {
                items(LinkFolder.entries) { f ->
                    FilterChip(selected = folder == f, onClick = { folder = f }, label = { Text(f.displayName) }, modifier = Modifier.padding(end = 6.dp, top = 6.dp))
                }
            }

            Spacer(Modifier.height(12.dp))
            Text("Статус", style = MaterialTheme.typography.titleSmall)
            LazyRow {
                items(LinkStatus.entries) { s ->
                    FilterChip(selected = status == s, onClick = { status = s }, label = { Text(s.label) }, modifier = Modifier.padding(end = 6.dp, top = 6.dp))
                }
            }

            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value = tags, onValueChange = { tags = it }, label = { Text("Теги (через кому)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Нотатки") }, minLines = 3, modifier = Modifier.fillMaxWidth())

            Spacer(Modifier.height(20.dp))
            Button(
                onClick = {
                    scope.launch {
                        repository.updateLink(
                            current.copy(
                                title = title,
                                thumbnailUrl = imageUrl.ifBlank { null },
                                tags = tags,
                                notes = notes,
                                folder = folder.name,
                                status = status.name,
                                isPinned = pinned
                            )
                        )
                        onBack()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Зберегти зміни") }
        }
    }
}
