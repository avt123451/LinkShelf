# Add project specific ProGuard rules here.
-keep class com.linkshelf.app.data.local.entity.** { *; }
