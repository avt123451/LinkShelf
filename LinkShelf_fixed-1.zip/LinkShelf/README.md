# LinkShelf

Android-додаток для збереження веб-посилань у вигляді карток з прев'ю (Kotlin + Jetpack Compose + Room).

## Важливо: що це і чого тут немає

Я не можу скомпілювати чи запустити реальний APK у цьому середовищі — тут немає Android SDK, емулятора
і мережі для завантаження Gradle-залежностей. Натомість це **повний, реальний вихідний код проєкту**,
готовий до відкриття в Android Studio (Koala/Ladybug+, JDK 17). Архітектура і код написані так, щоб
компілюватись і працювати, але перед першим запуском варто пройтись по проєкту в Android Studio —
IDE підсвітить, якщо десь потрібне дрібне виправлення (версії залежностей, тощо).

## Як відкрити

1. Android Studio → Open → обрати папку `LinkShelf/`.
2. Дочекатись Gradle sync (підтягне Compose, Room, Coil, OkHttp, Jsoup, Gson, WorkManager).
3. Запустити на пристрої / емуляторі з Android 12+ (minSdk 31).

## Що реалізовано

- **Room-база** (`data/local`) — сутність `LinkEntity` з усіма полями (url, title, thumbnail, favicon,
  domain, folder, status, tags, notes, pinned, дати), DAO з пошуком/фільтрами/сортуванням.
- **Open Graph парсер** (`data/metadata/OpenGraphFetcher.kt`) — через OkHttp + Jsoup витягує
  `og:title`, `og:description`, `og:image`, favicon; при помилці (сайт без preview) повертає
  безпечний fallback замість краху, як просилось у ТЗ.
- **Share з Chrome** (`share/ShareReceiverActivity.kt`) — прозора Activity на `ACTION_SEND` /
  `text/plain`, витягує URL навіть якщо Chrome прислав "Заголовок\nhttps://...", і передає в екран
  додавання з готовим прев'ю.
- **Головний екран** (`ui/screens/home`) — пошук, чіпи фільтрів за папками й статусом
  (переглянуто/не переглянуто), сортування (дата/назва/сайт), сітка карток 2 колонки,
  мультивибір (довге натискання) + масове переміщення в папку / видалення.
- **Картка** (`ui/components/LinkCard.kt`) — велике зображення, назва, домен + favicon, кольоровий
  бейдж статусу, кнопки "Статус" і "Відкрити", індикатор закріплення.
- **"Папки як вкладки браузера"** (бонус, `ui/screens/folders/FoldersScreen.kt` +
  `FolderTile.kt`) — сітка плиток з іконкою і лічильником елементів.
- **Додавання посилання** — вставка з буфера обміну, ручне введення, редагування заголовка й
  картинки вручну, вибір папки, теги, нотатки.
- **Деталі картки** — редагування всіх полів, зміна статусу/папки, закріплення, видалення.
- **Експорт/імпорт** (`data/export/ExportImportManager.kt`) — JSON (повний, без втрат) і CSV.
- **Офлайн-кеш зображень** — через Coil (диск-кеш "з коробки" для thumbnail/favicon).
- **Темна тема за замовчуванням**, заокруглені картки (`ui/theme`).

## Що залишено як розширення (з коментарями в коді, куди підключати)

- **Хмарна синхронізація між пристроями** — репозиторій спроєктований так, щоб під нього можна
  було підключити Firebase Firestore / власний бекенд (наприклад, синхронізувати `LinkEntity` як є).
  Зараз є лише локальний Room.
- **UI для експорту/імпорту та підключення хмари** — логіка (`ExportImportManager`) готова,
  бракує лише екрана "Налаштування" з кнопками виклику `ACTION_CREATE_DOCUMENT` /
  `ACTION_OPEN_DOCUMENT` для вибору файлу.
- **WorkManager** підключений у Gradle для фонового оновлення метаданих/синхронізації — воркер ще
  не написаний, це наступний логічний крок.
- Реальні PNG/adaptive-icon растрові mipmap — зараз іконка додатка як простий векторний плейсхолдер.

## Gradle Wrapper

Додано `gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.properties` і
`gradle/wrapper/gradle-wrapper.jar`. Тепер можна запускати збірку через:

```bash
./gradlew assembleDebug
```

Після цього APK з'явиться в `app/build/outputs/apk/debug/`.

## Структура проєкту

```
app/src/main/java/com/linkshelf/app/
  data/local/          Room: Entity, DAO, Database
  data/model/           LinkStatus, LinkFolder (enum-и)
  data/metadata/         Open Graph fetcher
  data/repository/       LinkRepository (єдина точка доступу до даних)
  data/export/            JSON/CSV експорт-імпорт
  ui/theme/                Тема (темна за замовчуванням)
  ui/components/            LinkCard, FolderTile, StatusBadge
  ui/screens/home/          Головний екран + ViewModel
  ui/screens/folders/       Екран "папки-вкладки"
  ui/screens/addlink/       Додавання посилання + ViewModel
  ui/screens/detail/        Деталі/редагування картки
  ui/navigation/             Navigation graph
  share/                     ShareReceiverActivity (інтеграція з Chrome)
```
